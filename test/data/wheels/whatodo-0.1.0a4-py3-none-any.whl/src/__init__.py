def main():
    """Entry point for the application script"""
    import src.main
    main.main()
    
