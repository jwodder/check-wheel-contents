#!/bin/python

import main
main.main()
