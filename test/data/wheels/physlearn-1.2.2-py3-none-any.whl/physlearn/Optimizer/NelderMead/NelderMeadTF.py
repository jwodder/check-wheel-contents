import math
import sys
import time

import numpy
import tensorflow as tf


