def calc_percents(array):
    return array * 100 / sum(array)
