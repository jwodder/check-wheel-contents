from physlearn.NeuralNet.NeuralNet import NeuralNet
from physlearn.NeuralNet.SubNet import SubNet
