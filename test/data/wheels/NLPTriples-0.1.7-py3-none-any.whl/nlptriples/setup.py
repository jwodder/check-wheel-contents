import nltk
import benepar
benepar.download('benepar_en2')