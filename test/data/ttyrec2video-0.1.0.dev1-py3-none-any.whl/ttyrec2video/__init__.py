"""
Convert ttyrec files to videos

Visit <https://github.com/jwodder/ttyrec2video> for more information.
"""

__version__      = '0.1.0.dev1'
__author__       = 'John Thorvald Wodder II'
__author_email__ = 'ttyrec2video@varonathe.org'
__license__      = 'MIT'
__url__          = 'https://github.com/jwodder/ttyrec2video'
